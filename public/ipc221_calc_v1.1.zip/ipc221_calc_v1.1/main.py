import sys, os
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

# This is a function that helps the executable know where the files are to build
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

# Constants
IPC_UNIT_HOLES = {
    "IPC Level A": {
        "mm": 0.25,
        "mils": 9.84252
    },
    "IPC Level B": {
        "mm": 0.2,
        "mils": 7.87402
    },
    "IPC Level C": {
        "mm": 0.15,
        "mils": 5.905512
    }
}
IPC_UNIT_PADS = {
    "IPC Level A": {
        "mm": 0.6,
        "mils": 23.622
    },
    "IPC Level B": {
        "mm": 0.5,
        "mils": 19.685
    },
    "IPC Level C": {
        "mm": 0.4,
        "mils": 15.748
    }
}

class IPC221_calc(object):
    """
        Comments here about what this class is
    """

    def __init__(self):
        """
        Comments about the init of the class
        """
        self.root = tk.Tk()

        self.background = tk.PhotoImage(file=resource_path("Pad_Stack.png"))

        self.gp_ipc_dropdown = None
        self.g_ipc_value = tk.StringVar()

        self.gp_units_dropdown = None
        self.g_units_value = tk.StringVar()
        self.g_last_unit = "mm"
        ######################################################################################
        self.estyle = None
        ######################################################################################

        self.gp_min_annular_ring = None
        self.g_min_annular_ring_value = tk.StringVar()

        self.gp_max_lead_diam = None
        self.g_max_lead_diam_value = tk.StringVar()

        self.gp_min_hole_size = None
        self.g_min_hole_size_value = tk.StringVar()

        self.gp_output_x = None
        self.g_output_x_value = tk.StringVar()
        self.gp_output_y = None
        self.g_output_y_value = tk.StringVar()
        self.gp_output_hole_size = None
        self.g_output_hole_size_value = tk.StringVar()

        self.config_root()
        self.root.mainloop()

    def __del__(self):
        """
        on delete stuff
        :return:
        """
        # self.root.destroy()

    def config_root(self):
        """
        comments here
        :return:
        """
        self.root.geometry('800x649')
        self.root.resizable(width=False, height=False)
        self.root.title("IPC221 Calculator")
        self.root.configure(background="#2e2e2e")

        self.root.columnconfigure((0, 2), weight=4)
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure((0, 1, 2, 3, 4), weight=1)

        label = tk.Label(self.root, textvariable=self.g_units_value)
        label.grid(row=0, column=0, padx=(200, 0), pady=(80, 0), sticky="N")
        label = tk.Label(self.root, textvariable=self.g_units_value)
        label.grid(row=0, column=0, padx=(200, 0), pady=(120, 0), sticky="N")
        label = tk.Label(self.root, textvariable=self.g_units_value)
        label.grid(row=0, column=0, padx=(200, 0), pady=(160, 0), sticky="N")

        self.config_ipc_level_dropdown(self.root)
        self.config_units_dropdown(self.root)
        self.config_min_annular_ring_entry(self.root)
        self.config_max_lead_diam_entry(self.root)
        self.config_min_hole_size_entry(self.root)
        self.config_output_frame(self.root)
        for widget in self.root.winfo_children():
            # check whether widget is instance of Label
            if isinstance(widget, tk.Label):
                widget.config(background="#2e2e2e", foreground="white")

    def config_ipc_level_dropdown(self, parent):
        """

        :param parent: root
        :return:
        """
        self.gp_ipc_dropdown = ttk.Combobox(parent,
                                            textvariable=self.g_ipc_value)
        self.gp_ipc_dropdown.grid(row=0, column=0, padx=(20, 0), sticky="n")
        self.gp_ipc_dropdown.configure(values=["IPC Level A", "IPC Level B", "IPC Level C"])
        self.gp_ipc_dropdown.current(0)
        self.gp_ipc_dropdown.configure(state="readonly")

        label = tk.Label(parent, text="IPC Level: ")
        label.grid(row=0, column=0, sticky="NW")
        self.g_ipc_value.trace('w', lambda e, f, g: self.calculate())

    def config_units_dropdown(self, parent):
        """

        :param parent: root
        :return:
        """
        self.gp_units_dropdown = ttk.Combobox(parent,
                                              textvariable=self.g_units_value)
        self.gp_units_dropdown.grid(row=0, column=0, padx=(20, 0), pady=(40, 0), sticky="N")
        self.gp_units_dropdown.configure(values=["mm", "mils"])
        self.gp_units_dropdown.current(0)
        self.gp_units_dropdown.configure(state="readonly")

        label = tk.Label(parent, text="Units: ")
        label.grid(row=0, column=0, sticky="NW", pady=(40, 0))

        self.g_units_value.trace('w', lambda e, f, g: self.unit_check())

    def config_min_annular_ring_entry(self, parent):
        """

        :param parent: root
        :return:
        """
        self.gp_min_annular_ring = ttk.Entry(parent,
                                             textvariable=self.g_min_annular_ring_value,
                                             width=15)
        self.gp_min_annular_ring.grid(row=0, column=0, padx=(65, 0), pady=(80, 0), sticky="N")
        self.g_min_annular_ring_value.set("0.05")

        label = tk.Label(parent, text="Min Annular Ring: ")
        label.grid(row=0, column=0, sticky="NW", pady=(80, 0))

        # self.gp_min_annular_ring.bind('<Leave>', lambda event: self.calculate())
        self.g_min_annular_ring_value.trace('w', lambda e, f, g: self.calculate())

    def config_max_lead_diam_entry(self, parent):
        """

        :param parent: root
        :return:
        """
        self.gp_max_lead_diam = ttk.Entry(parent,
                                          textvariable=self.g_max_lead_diam_value,
                                          width=14)
        self.gp_max_lead_diam.grid(row=0, column=0, padx=(70, 0), pady=(120, 0), sticky="N")

        label = tk.Label(parent, text="Max Lead Diameter: ")
        label.grid(row=0, column=0, sticky="NW", pady=(120, 0))

        # self.gp_max_lead_diam.bind('<Leave>', lambda event: self.calculate())
        self.g_max_lead_diam_value.trace('w', lambda e, f, g: self.calculate())

    def config_min_hole_size_entry(self, parent):
        """

        :param parent: root
        :return:
        """
        self.gp_min_hole_size = ttk.Entry(parent,
                                          textvariable=self.g_min_hole_size_value,
                                          width=15)
        self.gp_min_hole_size.grid(row=0, column=0, padx=(65, 0), pady=(160, 0), sticky="N")

        label = tk.Label(parent, text="Min Hole Size: ")
        label.grid(row=0, column=0, sticky="NW", pady=(160, 0))

        # self.gp_min_hole_size.bind('<Leave>', lambda event: self.calculate())
        self.g_min_hole_size_value.trace('w', lambda e, f, g: self.calculate())

    def config_output_frame(self, parent):
        """
        comments here
        :param parent: root
        :return: None
        """
        #####################################################################################
        estyle = ttk.Style()
        estyle.element_create("plain.field", "from", "clam")
        estyle.layout("EntryStyle.TEntry",
                      [('Entry.plain.field', {'children': [(
                          'Entry.background', {'children': [(
                              'Entry.padding', {'children': [(
                                  'Entry.textarea', {'sticky': 'nswe'})],
                                  'sticky': 'nswe'})], 'sticky': 'nswe'})],
                          'border': '2', 'sticky': 'nswe'})])
        estyle.configure("EntryStyle.TEntry",
                         background="green",
                         foreground="white",
                         fieldbackground="#2e2e2e",
                         highlightthickness=0,
                         borderwidth=0,
                         bd=0)
        #####################################################################################
        canvas = tk.Canvas(parent, width=420)
        canvas.grid(row=0, column=2, rowspan=5, sticky="NEWS")
        canvas.create_image(0, 0, image=self.background, anchor="nw")
        self.gp_output_x = ttk.Entry(parent,
                                     width=25,
                                     textvariable=self.g_output_x_value,
                                     style="EntryStyle.TEntry")
        self.gp_output_x["state"] = "readonly"
        entry_window1 = canvas.create_window(130, 355, anchor="nw", window=self.gp_output_x)
        self.gp_output_y = ttk.Entry(parent,
                                     width=25,
                                     textvariable=self.g_output_y_value,
                                     style="EntryStyle.TEntry")
        self.gp_output_y["state"] = "readonly"
        entry_window2 = canvas.create_window(305, 355, anchor="nw", window=self.gp_output_y)
        self.gp_output_hole_size = ttk.Entry(parent,
                                             width=55,
                                             textvariable=self.g_output_hole_size_value,
                                             style="EntryStyle.TEntry")
        self.gp_output_hole_size["state"] = "readonly"
        entry_window3 = canvas.create_window(130, 517, anchor="nw", window=self.gp_output_hole_size)

    def calculate(self):
        """
        Calculate some stuff
        :return:
        """
        if self.g_max_lead_diam_value.get() != "":
            self.g_min_hole_size_value.set('%.2f' % (float(self.g_max_lead_diam_value.get()) +
                                           IPC_UNIT_HOLES[self.gp_ipc_dropdown.get()][self.gp_units_dropdown.get()]))
        if self.g_min_hole_size_value.get() != "":
            pad_value = '%.2f' % (float(self.g_min_hole_size_value.get()) +
                                  (float(self.g_min_annular_ring_value.get()) * 2) +
                                  IPC_UNIT_PADS[self.gp_ipc_dropdown.get()][self.gp_units_dropdown.get()])
            self.g_output_x_value.set(str(pad_value))
            self.g_output_y_value.set(str(pad_value))
            self.g_output_hole_size_value.set(str('%.2f' % float(self.g_min_hole_size_value.get())))

    def unit_check(self):
        """
        Comments
        """
        if self.g_units_value.get() == self.g_last_unit:
            pass
        elif self.g_units_value.get() == "mm":
            if self.g_min_annular_ring_value.get() != "":
                self.g_min_annular_ring_value.set(str('%.2f' % (float(self.g_min_annular_ring_value.get()) / 39.37)))
            if self.g_max_lead_diam_value.get() != "":
                self.g_max_lead_diam_value.set(str('%.2f' % (float(self.g_max_lead_diam_value.get()) / 39.37)))
            if self.g_min_hole_size_value.get() != "":
                self.g_min_hole_size_value.set(str('%.2f' % (float(self.g_min_hole_size_value.get()) / 39.37)))
            # if self.g_output_x_value.get() != "":
            #     self.g_output_x_value.set(str('%.2f' % (float(self.g_output_x_value.get()) / 39.37)))
            # if self.g_output_y_value.get() != "":
            #     self.g_output_y_value.set(str('%.2f' % (float(self.g_output_y_value.get()) / 39.37)))
            # if self.g_output_hole_size_value.get() != "":
            #     self.g_output_hole_size_value.set(str('%.2f' % (float(self.g_output_hole_size_value.get()) / 39.37)))
        elif self.g_units_value.get() == "mils":
            if self.g_min_annular_ring_value.get() != "":
                self.g_min_annular_ring_value.set(str('%.2f' % (float(self.g_min_annular_ring_value.get()) * 39.37)))
            if self.g_max_lead_diam_value.get() != "":
                self.g_max_lead_diam_value.set(str('%.2f' % (float(self.g_max_lead_diam_value.get()) * 39.37)))
            if self.g_min_hole_size_value.get() != "":
                self.g_min_hole_size_value.set(str('%.2f' % (float(self.g_min_hole_size_value.get()) * 39.37)))
            # if self.g_output_x_value.get() != "":
            #     self.g_output_x_value.set(str('%.2f' % (float(self.g_output_x_value.get()) * 39.37)))
            # if self.g_output_y_value.get() != "":
            #     self.g_output_y_value.set(str('%.2f' % (float(self.g_output_y_value.get()) * 39.37)))
            # if self.g_output_hole_size_value.get() != "":
            #     self.g_output_hole_size_value.set(str('%.2f' % (float(self.g_output_hole_size_value.get()) * 39.37)))
        self.g_last_unit = self.g_units_value.get()

variable = IPC221_calc()
